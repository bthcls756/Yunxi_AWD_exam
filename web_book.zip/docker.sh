#!/bin/sh
cp run.sh book/
cp flag.py book/
cp my.cnf book/
docker run -p {out_port}:80  -p {ssh_port}:22 -p {mysql_port}:3306 -v `pwd`/book:/var/www/html -d  --name {team_name} -ti web_14.04 /var/www/html/run.sh