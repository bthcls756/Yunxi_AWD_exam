#!/bin/sh
cd /var/www/html

mv my.cnf /etc/mysql/

service ssh start
a2enmod rewrite
service apache2 start
service mysql start

sleep 10

python flag.py &  2>&1 1>/dev/null

useradd ctf
echo ctf:moxiaoxi666 | chpasswd

sleep 3

mysql -uroot -proot < database/obs_db.sql
mysql -e "SET GLOBAL secure_file_priv=''; FLUSH PRIVILEGES;"

rm -rf flag.py
rm -rf run.sh

if [ -x "extra.sh" ]; then 
./extra.sh
fi
/bin/bash