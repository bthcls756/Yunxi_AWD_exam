#!/usr/bin/env python
# -*- coding:utf8 -*-
import requests
import base64
import random
import string

def index_check(target_url):
    res = requests.get(target_url + '/index.php')
    if 'Android Studio New Media Fundamentals'.encode() in res.content:
        return True
    return False

def book_check(target_url):
    res = requests.get(target_url + '/book.php?bookisbn=978-1-484216-40-8')
    if 'Wallace Jackson'.encode() in res.content:
        return True
    return False

def book_check(target_url):
    res = requests.get(target_url + '/book.php?bookisbn=978-1-484216-40-8')
    if 'Wallace Jackson'.encode() in res.content:
        return True
    return False

def ping_check(target_url):
    res = requests.get(target_url + '/functions/database_functions.php?target=127.0.0.1')
    if 'PING 127.0.0.1 (127.0.0.1) 56(84) bytes of data'.encode() in res.content:
        return True
    return False

def login_check(target_url):
    session = requests.Session()
    paramsPost = {"submit": "提交查询", "pass": "mama123", "name": "admin"}
    headers = {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
               "Upgrade-Insecure-Requests": "1",
               "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:68.0) Gecko/20100101 Firefox/68.0",
               "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
               "Accept-Encoding": "gzip, deflate", "Content-Type": "application/x-www-form-urlencoded"}
    cookies = {"PHPSESSID": "imacgp63jd5nsmdaro91lpbkq3","sessionid": "mf2f01tezkv5c0a8yze8jw54aiesmeq2"}
    response = session.post(target_url + "/admin_verify.php", data=paramsPost, headers=headers, cookies=cookies)
    if '<title>List book</title>'.encode() in response.content:
        return True
    return False

def admin_indec_check(target_url):
    session = requests.Session()
    headers = {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
               "Upgrade-Insecure-Requests": "1",
               "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:68.0) Gecko/20100101 Firefox/68.0",
               "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
               "Accept-Encoding": "gzip, deflate", "Content-Type": "application/x-www-form-urlencoded"}
    cookies = {"PHPSESSID": "imacgp63jd5nsmdaro91lpbkq3","sessionid": "mf2f01tezkv5c0a8yze8jw54aiesmeq2"}
    response = session.get(target_url + "/admin_book.php", headers=headers, cookies=cookies)
    if '<h4 class="fw-bolder text-center">Book List</h4>'.encode() in response.content:
        return True
    return False

def admin_edit_check(target_url):
    session = requests.Session()
    headers = {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
               "Upgrade-Insecure-Requests": "1",
               "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:68.0) Gecko/20100101 Firefox/68.0",
               "Accept-Language": "zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
               "Accept-Encoding": "gzip, deflate", "Content-Type": "application/x-www-form-urlencoded"}
    cookies = {"PHPSESSID": "imacgp63jd5nsmdaro91lpbkq3","sessionid": "mf2f01tezkv5c0a8yze8jw54aiesmeq2"}
    response = session.get(target_url + "/admin_edit.php?bookisbn=978-1-484217-26-9", headers=headers, cookies=cookies)
    if 'C++ 14 Quick Syntax Reference, 2nd Edition'.encode() in response.content:
        return True
    return False

def check(target_ip, target_port):
    target_url = 'http://' + target_ip + ':' + str(target_port)
    if not index_check(target_url):
        print("[-]: {},index_check error".format(target_url))
        return False
    print("[+]:{},index check succ!".format(target_url))

    if not book_check(target_url):
        print("[-]: {},book_check error".format(target_url))
        return False
    print("[+]:{},book check succ!".format(target_url))

    if not ping_check(target_url):
        print("[-]: {},ping_check error".format(target_url))
        return False
    print("[+]:{},ping check succ!".format(target_url))

    if not login_check(target_url):
        print("[-]: {},login_check error".format(target_url))
        return False
    print("[+]:{},login check succ!".format(target_url))

    if not admin_indec_check(target_url):
        print("[-]: {},admin_indec_check error".format(target_url))
        return False
    print("[+]:{},admin_indec check succ!".format(target_url))

    if not admin_edit_check(target_url):
        print("[-]: {},admin_edit_check error".format(target_url))
        return False
    print("[+]:{},admin_edit check succ!".format(target_url))

    return True



    
if __name__ == '__main__':
    target_ip, target_port = '127.0.0.1', 8801
    check(target_ip, target_port)
